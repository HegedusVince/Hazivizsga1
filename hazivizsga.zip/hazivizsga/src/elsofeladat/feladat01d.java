package elsofeladat;

public class feladat01d {
    public static void main(String[] args) {
        String encryptedText = "9753371051";
        String expectedDecryptedText = "Hello, world!";
        testDecryption(encryptedText, expectedDecryptedText);
        encryptedText = "";
        expectedDecryptedText = "";
        testDecryption(encryptedText, expectedDecryptedText);
        encryptedText = "9753#9!0";
        expectedDecryptedText = "Helloworld";
        testDecryption(encryptedText, expectedDecryptedText);
    }
    
    public static void testDecryption(String encryptedText, String expectedDecryptedText) {
        dekodolas dekodolas = new dekodolas();
        String decryptedText = dekodolas.dekodolas(encryptedText);
        
        System.out.println("Titkosított szöveg: " + encryptedText);
        System.out.println("Várt eredmény: " + expectedDecryptedText);
        System.out.println("Dekódolt szöveg: " + decryptedText);
        System.out.println("Eredmény: " + (decryptedText.equals(expectedDecryptedText) ? "Sikeres" : "Sikertelen"));
        System.out.println();
    }
}