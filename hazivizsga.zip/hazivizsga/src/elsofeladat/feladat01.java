package elsofeladat;

public class feladat01 {
    public static void main(String[] args) {
        String titkositas = "Sikeres Vizsga!";
        
    
        String titkositasText = titkositas;
        System.out.println("Titkosított szöveg: " + titkositasText);
        
       
        String decryptedText = decrypt(titkositasText);
        System.out.println("Dekódolt szöveg: " + decryptedText);
    }
    


	public static String encrypt(String text) {
        StringBuilder titkositas = new StringBuilder();
        
      
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            switch (c) {
                case 'k':
                	titkositas.append('3');
                    break;
                    case 's':
                    titkositas.append('3');
                    break;
                case 't':
                	titkositas.append('5');
                    break;
                case 'e':
                	titkositas.append('7');
                    break;
                case 'a':
                	titkositas.append('9');
                    break;
                case ' ':
                	titkositas.append('0');
                    break;
                default:
                	titkositas.append(c);
                    break;
            }
        }
        
        
        if (titkositas.length() > 0) {
            char lastChar = titkositas.charAt(titkositas.length() - 1);
            titkositas.deleteCharAt(titkositas.length() - 1);
            titkositas.insert(0, lastChar);
        }
        
        return titkositas.toString();
    }
    
    public static String decrypt(String titkositasText) {
        StringBuilder dekodolas = new StringBuilder();
        
        
        if (titkositasText.length() > 0) {
            char firstChar = titkositasText.charAt(0);
            dekodolas.append(titkositasText, 1, titkositasText.length()).append(firstChar);
        }
        
      
        for (int i = 0; i < dekodolas.length(); i++) {
            char c = dekodolas.charAt(i);
            switch (c) {
                case '1':
                	dekodolas.setCharAt(i, 'k');
                    break;
                case '3':
                	dekodolas.setCharAt(i, 's');
                    break;
                case '5':
                	dekodolas.setCharAt(i, 't');
                    break;
                case '7':
                	dekodolas.setCharAt(i, 'e');
                    break;
                case '9':
                dekodolas.setCharAt(i, 'a');
                    break;
                case '0':
                	dekodolas.setCharAt(i, ' ');
                    break;
                default:
                    break;
            }
        }
        
        return dekodolas.toString();
    }


}
