package elsofeladat;

import java.util.Scanner;

public class feladat01c {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Adjon meg egy titkosítandó szöveget:");
        String inputText = scanner.nextLine();
        
        titkositas titkositas = new titkositas();
        String titkositasText = titkositas.titkositas(inputText);
        System.out.println("Titkosított szöveg: " + titkositasText);
        
        dekodolas dekodolas = new dekodolas();
        String dekodolasText = dekodolas.dekodolas(titkositasText);
        System.out.println("Dekódolt szöveg: " + dekodolasText);
    }
}

class titkositas {
    public String titkositas(String text) {
        StringBuilder titkositas = new StringBuilder();
        
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            switch (c) {
                case 'k':
                	titkositas.append('1');
                    break;
                case 's':
                	titkositas.append('3');
                    break;
                case 't':
                	titkositas.append('5');
                    break;
                case 'e':
                	titkositas.append('7');
                    break;
                case 'a':
                	titkositas.append('9');
                    break;
                case ' ':
                	titkositas.append('0');
                    break;
                default:
                	titkositas.append(c);
                    break;
            }
        }
        
        if (titkositas.length() > 0) {
            char lastChar = titkositas.charAt(titkositas.length() - 1);
            titkositas.deleteCharAt(titkositas.length() - 1);
            titkositas.insert(0, lastChar);
        }
        
        return titkositas.toString();
    }
}

class dekodolas {
    public String dekodolas(String titkositasText) {
        StringBuilder dekodolas = new StringBuilder();
        
        if (titkositasText.length() > 0) {
            char firstChar = titkositasText.charAt(0);
            dekodolas.append(titkositasText.substring(1)).append(firstChar);
        }
        
        for (int i = 0; i < dekodolas.length(); i++) {
            char c = dekodolas.charAt(i);
            switch (c) {
                case '1':
                	dekodolas.setCharAt(i, 'k');
                    break;
                case '3':
                	dekodolas.setCharAt(i, 's');
                    break;
                case '5':
                	dekodolas.setCharAt(i, 't');
                    break;
                case '7':
                	dekodolas.setCharAt(i, 'e');
                    break;
                case '9':
                	dekodolas.setCharAt(i, 'a');
                    break;
                case '0':
                	dekodolas.setCharAt(i, ' ');
                    break;
                default:
                    break;
            }
        }
        
        return dekodolas.toString();
    }
}