package harmadikfeladat;

public class Foproba extends SzervizMunka {

	public Foproba(String tevekenyseg, int munkaorak) {
		public static void main(String[] args) {
	    double oradij = 8000; 
		 
        SzervizMunka munka1 = new SzervizMunka("Olajcsere", 2);
        double ar1 = munka1.arKepzes(oradij);
        System.out.println("Tevékenység: " + munka1.getTevekenyseg());
        System.out.println("Munkaórák: " + munka1.getMunkaorak());
        System.out.println("Munkadíj: " + ar1);

        SzervizMunka munka2 = new SzervizMunka("Fékjavítás", 3);
        double ar2 = munka2.arKepzes(oradij);
        System.out.println("Tevékenység: " + munka2.getTevekenyseg());
        System.out.println("Munkaórák: " + munka2.getMunkaorak());
        System.out.println("Munkadíj: " + ar2);
    }
}

}