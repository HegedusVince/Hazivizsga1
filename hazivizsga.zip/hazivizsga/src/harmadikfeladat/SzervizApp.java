package harmadikfeladat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class SzervizApp {
    public static void main(String[] args) {
        List<SzervizMunka> szervizMunkak = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Szervíz munkák rögzítése");
        System.out.println("Kilépéshez üres értéket adjon meg a tevékenység mezőben.");

        while (true) {
            System.out.print("Tevékenység: ");
            String tevekenyseg = scanner.nextLine();

            if (tevekenyseg.isEmpty()) {
                break;
            }

            System.out.print("Munkaórák: ");
            int munkaorak = Integer.parseInt(scanner.nextLine());

            SzervizMunka szervizMunka = new SzervizMunka(tevekenyseg, munkaorak);
            szervizMunkak.add(szervizMunka);
        }

        Map<String, Double> munkadijak = new HashMap<>();
        for (SzervizMunka szervizMunka : szervizMunkak) {
            double ar = szervizMunka.arKepzes(8000); // Aktuális óradíj
            munkadijak.put(szervizMunka.getTevekenyseg(), ar);
        }

        System.out.println("\nRögzített szervíz munkák és munkadíjak:");
        for (Map.Entry<String, Double> entry : munkadijak.entrySet()) {
            String tevekenyseg = entry.getKey();
            double ar = entry.getValue();
            System.out.println("Tevékenység: " + tevekenyseg);
            System.out.println("Munkadíj: " + ar);
            System.out.println();
        }
    }
}