package harmadikfeladat;

public class SzervizMunka  {
	    private String tevekenyseg;
	    private int munkaorak;

		public SzervizMunka(String tevekenyseg2, int munkaorak2) {
			// TODO Auto-generated constructor stub
		}

		public void SzervizMunka(String tevekenyseg, int munkaorak) {
	        this.tevekenyseg = tevekenyseg;
	        this.munkaorak = munkaorak;
	    }

	    public String getTevekenyseg() {
	        return tevekenyseg;
	    }

	    public int getMunkaorak() {
	        return munkaorak;
	    }

	    public double arKepzes(double oradij) {
	        return oradij * munkaorak;
	    }
	}


