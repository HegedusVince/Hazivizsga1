package otodikfeladat;

import java.util.Date;

public class SzinhaziEloadas {
    private String cim;
    private String rendezo;
    private Date bemutatoDatum;
    private int tervezettEloadasokSzama;

    public SzinhaziEloadas(String cim, String rendezo, Date bemutatoDatum, int tervezettEloadasokSzama) {
        this.cim = cim;
        this.rendezo = rendezo;
        this.bemutatoDatum = bemutatoDatum;
        this.tervezettEloadasokSzama = tervezettEloadasokSzama;
    }

    // Getterek és setterek

    public String getCim() {
        return cim;
    }

    public void setCim(String cim) {
        this.cim = cim;
    }

    public String getRendezo() {
        return rendezo;
    }

    public void setRendezo(String rendezo) {
        this.rendezo = rendezo;
    }

    public Date getBemutatoDatum() {
        return bemutatoDatum;
    }

    public void setBemutatoDatum(Date bemutatoDatum) {
        this.bemutatoDatum = bemutatoDatum;
    }

    public int getTervezettEloadasokSzama() {
        return tervezettEloadasokSzama;
    }

    public void setTervezettEloadasokSzama(int tervezettEloadasokSzama) {
        this.tervezettEloadasokSzama = tervezettEloadasokSzama;
    }

    @Override
    public String toString() {
        return "Cím: " + cim + "\n" +
                "Rendező: " + rendezo + "\n" +
                "Bemutató dátuma: " + bemutatoDatum + "\n" +
                "Tervezett előadások száma: " + tervezettEloadasokSzama;
    }
}
