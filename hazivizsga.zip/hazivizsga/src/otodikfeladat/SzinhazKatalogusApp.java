package otodikfeladat;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import java.awt.BorderLayout;
import java.util.List;

public class SzinhazKatalogusApp extends JFrame {
    private JList<SzinhaziEloadas> eloadasLista;

    public SzinhazKatalogusApp() {
        setTitle("Színház Katalógus");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);

        eloadasLista = new JList<>();
        eloadasLista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(eloadasLista);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        add(panel);
    }

    public void adatokBetoltese(List<SzinhaziEloadas> eloadasok) {
        eloadasLista.setListData(eloadasok.toArray(new SzinhaziEloadas[0]));
    }

    public static void main(String[] args) {
        SzinhazKatalogusApp app = new SzinhazKatalogusApp();
        AdatbazisKapcsolat adatbazisKapcsolat = new AdatbazisKapcsolat();
        List<SzinhaziEloadas> eloadasok = adatbazisKapcsolat.szinhaziEloadasokatBetolt();

        app.adatokBetoltese(eloadasok);
        app.setVisible(true);
    }
}