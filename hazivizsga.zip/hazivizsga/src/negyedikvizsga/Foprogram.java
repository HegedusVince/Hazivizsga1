package negyedikvizsga;

public class Foprogram {

	public static void main(String[] args) {
		        SzallitoiRendelesekFeldolgozo feldolgozo = new SzallitoiRendelesekFeldolgozo();
		        int hibasSorokSzama = feldolgozo.beolvas("SzallitoiRendelesek.csv");

		        if (hibasSorokSzama > 0) {
		            System.out.println("Hibás sorok száma: " + hibasSorokSzama);
		        }

		        feldolgozo.ellenoriz();
		    }
		
	}
