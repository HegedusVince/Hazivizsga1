package negyedikvizsga;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SzallitoiRendelesekFeldolgozo {
    private List<SzallitoiRendeles> rendelesek;

    public SzallitoiRendelesekFeldolgozo() {
        rendelesek = new ArrayList<>();
    }

    public int beolvas(String fajlnev) {
        int hibasSorokSzama = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(fajlnev))) {
            String sor;
            while ((sor = br.readLine()) != null) {
                String[] adatok = sor.split(";");
                if (adatok.length >= 5 && adatok[0].length() >= 5) {
                    try {
                        int szallitolevelAzonosito = Integer.parseInt(adatok[0]);
                        String tetelMegnevezes = adatok[1];
                        int mennyiseg = Integer.parseInt(adatok[2]);
                        double osszertek = Double.parseDouble(adatok[3]);
                        boolean surgossegiSzallitas = adatok[4].equals("1");

                        SzallitoiRendeles rendeles = new SzallitoiRendeles(szallitolevelAzonosito, tetelMegnevezes, mennyiseg, osszertek, surgossegiSzallitas);
                        rendelesek.add(rendeles);
                    } catch (NumberFormatException e) {
                        hibasSorokSzama++;
                    }
                } else {
                    hibasSorokSzama++;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return hibasSorokSzama;
    }

    public void ellenoriz() {
        for (SzallitoiRendeles rendeles : rendelesek) {
            System.out.println(rendeles.toString());
        }
    }
}