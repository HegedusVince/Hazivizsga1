package negyedikvizsga;

public class SzallitoiRendeles {
    private int szallitolevelAzonosito;
    private String tetelMegnevezes;
    private int mennyiseg;
    private double osszertek;
    private boolean surgossegiSzallitas;

    public void Rendeles(int szallitolevelAzonosito, String tetelMegnevezes, int mennyiseg, double osszertek, boolean surgossegiSzallitas) {
        this.szallitolevelAzonosito = szallitolevelAzonosito;
        this.tetelMegnevezes = tetelMegnevezes;
        this.mennyiseg = mennyiseg;
        this.osszertek = osszertek;
        this.surgossegiSzallitas = surgossegiSzallitas;
    }

	public int getSzallitolevelAzonosito() {
		return szallitolevelAzonosito;
	}

	public void setSzallitolevelAzonosito(int szallitolevelAzonosito) {
		this.szallitolevelAzonosito = szallitolevelAzonosito;
	}

	public String getTetelMegnevezes() {
		return tetelMegnevezes;
	}

	public void setTetelMegnevezes(String tetelMegnevezes) {
		this.tetelMegnevezes = tetelMegnevezes;
	}

	public int getMennyiseg() {
		return mennyiseg;
	}

	public void setMennyiseg(int mennyiseg) {
		this.mennyiseg = mennyiseg;
	}

	public double getOsszertek() {
		return osszertek;
	}

	public void setOsszertek(double osszertek) {
		this.osszertek = osszertek;
	}

	public boolean isSurgossegiSzallitas() {
		return surgossegiSzallitas;
	}

	public void setSurgossegiSzallitas(boolean surgossegiSzallitas) {
		this.surgossegiSzallitas = surgossegiSzallitas;
	}

   
}