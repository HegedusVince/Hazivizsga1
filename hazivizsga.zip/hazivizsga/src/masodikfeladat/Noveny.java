package masodikfeladat;

import java.time.LocalDate;
import java.time.Period;

public class Noveny {
    private int azonosito;
    private String megnevezes;
    private int bekerulesEve;

    public Noveny(int azonosito, String megnevezes, int bekerulesEve) {
        this.azonosito = azonosito;
        this.megnevezes = megnevezes;
        this.bekerulesEve = bekerulesEve;
    }

    public int getAzonosito() {
        return azonosito;
    }

    public String getMegnevezes() {
        return megnevezes;
    }

    public int getBekerulesEve() {
        return bekerulesEve;
    }

    public int getLathatosagiIdo() {
        LocalDate currentDate = LocalDate.now();
        LocalDate bekerulesDatum = LocalDate.of(bekerulesEve, 1, 1);
        Period period = Period.between(bekerulesDatum, currentDate);
        return period.getMonths();
    }

@Override
public String toString() {
    return "Azonosító: " + azonosito +
           "\nMegnevezés: " + megnevezes +
           "\nBekerülés éve: " + bekerulesEve;
}
}
