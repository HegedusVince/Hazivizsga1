package masodikfeladat;

class  Foablak{
	 public static void main(String[] args) {
	        Noveny[] novenyek = new Noveny[4];
	        novenyek[0] = new Noveny(1, "Rózsa", 2010);
	        novenyek[1] = new Virag(2, "Tulipán", 2015, "Piros");
	        novenyek[2] = new Noveny(3, "Napraforgó", 2005);
	        novenyek[3] = new Virag(4, "Liliom", 2018, "Fehér");
	        
	        
	        printNovenyek(novenyek);
	    }
	    
	    public static void printNovenyek(Noveny[] novenyek) {
	        for (Noveny noveny : novenyek) {
	            System.out.println(noveny.toString());
	            if (noveny instanceof Virag) {
	                Virag virag = (Virag) noveny;
	                System.out.println("Virág színe: " + virag.getSzin());
	            }
	            int lathatosagiIdo = noveny.getLathatosagiIdo();
	            System.out.println("Látogathatósági idő (hónapok): " + lathatosagiIdo);
	            System.out.println("Példány típusa: " + (noveny instanceof Virag ? "Virág" : "Általános növény"));
	            System.out.println();
	        }
	    }
}
