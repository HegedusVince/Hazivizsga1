package masodikfeladat;

public class Virag extends Noveny {
    private String szin;

    public Virag(int azonosito, String megnevezes, int bekerulesEve, String szin) {
        super(azonosito, megnevezes, bekerulesEve);
        this.szin = szin;
    }

    public String getSzin() {
        return szin;
    }

    public void setSzin(String szin) {
        this.szin = szin;
    }

public String toString() {
    return super.toString() +
           "\nSzín: " + szin;
}
}